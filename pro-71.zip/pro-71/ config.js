import * as firebase from 'firebase';
require('@firebase/firestore')
const firebaseConfig = {
    apiKey: "AIzaSyDZE1LzKV0kidgselBpePzB_k77VwOYDiM",
    authDomain: "pro-71-a694f.firebaseapp.com",
    databaseURL: "https://pro-71-a694f-default-rtdb.firebaseio.com",
    projectId: "pro-71-a694f",
    storageBucket: "pro-71-a694f.appspot.com",
    messagingSenderId: "277362541085",
    appId: "1:277362541085:web:0d1799718d25268085fcf4",
    measurementId: "G-L7VRSWKVJS"
     };

     // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  export default firebase.firestore();