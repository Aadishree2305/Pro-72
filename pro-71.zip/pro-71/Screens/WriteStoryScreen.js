import React from 'react';
import {Text ,View ,StyleSheet ,TextInput ,TouchableOpacity} from 'react-native';
import db from '../ config';

export default class ReadStoryScreen extends React.Component{

  constructor(){
    super();
    this.setState={
      submitStory:'',
    }
  }
    render(){
        return(
            <View style>
            <TextInput 
              style={styles.inputBoxName}
              placeholder="Name of the story"
              onChangeText={text => this.setState({scannedBookId:text})}/>

              <TextInput 
              style={styles.inputBoxAuthor}
              placeholder="Name of the author"
              onChangeText={text => this.setState({scannedBookId:text})}/>

              <TextInput 
              style={styles.inputBoxWrite}
              placeholder="Write the story"
              onChangeText={text => this.setState({scannedBookId:text})}/>

              <TouchableOpacity
              style = {styles.submitButton}
              onPress={this.submitStory}>
              <Text style={styles.submitButtonText}>Submit</Text>
              </TouchableOpacity>
                </View>
        );
    }
}

const styles = StyleSheet.create({
  inputBoxName:{
      width: 200,
      height: 40,
      borderWidth: 1.5,
      borderRightWidth: 0,
      fontSize: 20,
      marginTop:40,
      alignContent:'center',
      alignSelf:'center',
    },

    inputBoxAuthor:{
      width: 200,
      height: 40,
      borderWidth: 1.5,
      borderRightWidth: 0,
      fontSize: 20,
      marginTop:40,
      alignContent:'center',
      alignSelf:'center',
    },

    inputBoxWrite:{
      width: 200,
      height: 40,
      borderWidth: 1.5,
      borderRightWidth: 0,
      fontSize: 20,
      marginTop:40,
      alignContent:'center',
      alignSelf:'center',
    },

    submitButton:{ 
      backgroundColor: '#6784ff', 
      width: 100, 
      height:50, 
      marginLeft:110,
      }, 
    submitButtonText:{ 
        padding: 10, 
        textAlign: 'center', 
        fontSize: 20, 
        fontWeight:"bold", 
        color: 'white' 
        }


})